<?php

class Category extends Controller {
    public function index()
    {
        if (empty(session('isAdmin'))) {
            redirect(url('login'));
        } else {
            $this->admin('category', [
                'categories' => $this->model('category')->findAll()
            ]);
        }
    }

    public function delete() {
        $this->model('category')->delete(post('id'));
        $this->toJson([
            'url' => url('admin/category'),
            'error' => false
        ]);
    }

    public function save() {
        $data['name'] = post('name');
        $data['slug'] = friendlyUrl(post('name'));

        if (empty(post('name')))
        {
            $output['error'] = true;
            $output['message'] = 'Nama masih kosong.';
        }

        $model = $this->model('category');

        if ( ! empty($model->findWhere('slug', friendlyUrl(post('name')))))
        {
            $output['error'] = true;
            $output['message'] = 'Nama masih tidak boleh sama.';
        }
        else
        {
            if (is_numeric(post('id')))
            {
                if ($model->update(post('id'), $data))
                {
                    $output['url'] = url('admin/category');
                    $output['error'] = false;
                }
                else
                {
                    $output['error'] = true;
                    $output['message'] = 'Terjadi masalah saat memperbaharui data!';
                }
            }
            else
            {
                if ($model->insert($data))
                {
                    $output['url'] = url('admin/category');
                    $output['error'] = false;
                }
                else
                {
                    $output['error'] = true;
                    $output['message'] = 'Terjadi masalah saat menyimpan data!';
                }
            }
        }

        $this->toJson($output);
    }
}

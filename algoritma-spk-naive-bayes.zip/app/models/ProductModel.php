<?php

class ProductModel extends Model {
    public function delete($id) {
        return $this->db->where('id', $id)->delete('products');
    }

    public function findAll(){
        $this->db->join('categories b', 'a.category_id = b.id', 'LEFT');
        return $this->db->get('products a', null, 'a.*, b.name as category');
	}

    public function findHome($search, $category){
        if (!empty($search)) {
            $this->db->where('a.name', $search, 'like');
        }
        
        if (!empty($category)) {
            $this->db->where('b.slug', $category);
        }
        
        $this->db->join('categories b', 'a.category_id = b.id', 'LEFT');
        return $this->db->get('products a', null, 'a.*, b.name as category');
	}

    public function findLast($count = null){
        $this->db->join('categories b', 'a.category_id = b.id', 'LEFT');
        return $this->db->orderBy('id', 'desc')->get('products a', $count, 'a.*, b.name as category');
	}

    public function findOne($id){
        return $this->db->where('id', $id)->getOne('products');
	}

    public function findWhere($key, $val){
        return $this->db->where($key, $val)->get('products');
	}

    public function insert($data){
        return $this->db->insert('products', $data);
	}

    public function update($id, $data){
        return $this->db->where('id', $id)->update('products', $data);
	}
}
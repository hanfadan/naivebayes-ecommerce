<?php

class CategoryModel extends Model {
    public function delete($id) {
        return $this->db->where('id', $id)->delete('categories');
    }

    public function findAll(){
        return $this->db->get('categories');
	}

    public function findOne($id){
        return $this->db->where('id', $id)->getOne('categories');
	}

    public function findWhere($key, $val){
        return $this->db->where($key, $val)->get('categories');
	}

    public function insert($data){
        return $this->db->insert('categories', $data);
	}

    public function update($id, $data){
        return $this->db->where('id', $id)->update('categories', $data);
	}
}
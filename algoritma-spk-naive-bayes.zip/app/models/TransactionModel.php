<?php

class TransactionModel extends Model {
    public function code(){
        $data = $this->db->rawQueryOne('SELECT max(RIGHT(invoice,4)) as code FROM transactions  WHERE DATE(created) = CURDATE()');
        $code = $data['code'];
        $order = intval($code);
        $order++;

		return 'INV'.date('Ymd'). sprintf('%04s', $order);
	}

    public function deleteCart($id) {
		return $this->db->where('id', $id)->delete('carts');
	}

    public function findAll() {
		$this->db->join('users b', 'a.user_id = b.id', 'LEFT');
        return $this->db->get('transactions a', null, 'a.id, a.total, a.invoice, b.name as user');
	}

    public function findDetails($invoice) {
		$trans = $this->db->where('invoice', $invoice)->getOne('transactions');

        $this->db->where('a.tran_id', $trans['id']);
        $this->db->join('products b', 'a.product_id = b.id', 'LEFT');
        return $this->db->get('transactions_details a', null, 'a.id, a.qty, a.price, b.name as product');
	}

    public function findLast() {
		return $this->db->getOne('transactions');
	}

    public function naiveBayes() {
        $query = 'SELECT SUM(transactions_details.qty) as qty, products.*, categories.name as category FROM transactions_details ';
        $query .= 'INNER JOIN products ON products.id=transactions_details.product_id ';
        $query .= 'INNER JOIN categories ON categories.id=products.category_id GROUP BY transactions_details.product_id ORDER BY qty DESC';
        return $this->db->rawQuery($query);
    }

    public function store($data) {
		return $this->db->insert('transactions', $data);
	}

    public function storeProduct($data) {
        if ($this->db->insertMulti('transactions_details', $data)) {
            return true;
        }
        
		return false;
	}

    public function totalAll() {
		return $this->db->getValue('transactions', 'count(id)') ?: 0;
	}

    public function totalMonth() {
        $this->db->where('YEAR(created)', date('Y'));
        $this->db->where('MONTH(created)', date('m'));
		return $this->db->getValue('transactions', 'count(id)') ?: 0;
	}

    public function totalNow() {
        $this->db->where('DATE(created)', date('Y-m-d'));
		return $this->db->getValue('transactions', 'count(id)') ?: 0;
	}

    public function totalUser() {
        $this->db->where('role', 'user');
		return $this->db->getValue('users', 'count(id)') ?: 0;
	}
}